# EmpiricistSegmentManager
This repository contains the files and code for team Empiricist for B'19 Software Engineering Group Project. 
