package empiricist.http;

import empiricist.model.Segment;

public class AppendSegmentRequest {
/*
	public String id;
	public Segment seg;
	public String playName;
	public boolean system;

	public AppendSegmentRequest(String id, Segment seg, String playName, boolean system) {
		this.id = id;
		this.seg = seg;
		this.playName = playName;
		this.system = system;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Segment getSeg() {
		return this.seg;
	}

	public void setSeg(Segment s) {
		this.seg = s;
	}

	public String getPlayName() {
		return this.playName;
	}

	public void setPlayName(String pname) {
		this.playName = pname;
	}

	public boolean getSystem() {
		return this.system;
	}

	public void setSystem(boolean sys) {
		this.system = sys;
	}

	public String toString() {
		return "Append Segment(" + id + "to" + playName + ")";
	}
	*/
}
