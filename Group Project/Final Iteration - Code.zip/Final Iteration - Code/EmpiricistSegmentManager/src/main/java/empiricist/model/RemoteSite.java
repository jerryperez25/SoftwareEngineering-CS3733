package empiricist.model;

public class RemoteSite {
	
	private String Url;

	
	public RemoteSite(String URL) {
		this.Url = URL;
	}
	
	public  String getUrl() {
		return Url;
	}
	//
	
}
